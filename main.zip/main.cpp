#include <iostream>

using namespace std;

int main()
{
  int Greenbottles =10;

  cout<<" There were"<<" "<<Greenbottles<<" "<<"green bottles"<<endl;

  Greenbottles--;
   cout<<" There were"<<" "<<Greenbottles<<" "<<"green bottles";
    return 0;
}
